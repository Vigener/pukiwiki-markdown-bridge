import"./modulepreload-polyfill-B5Qt9EMX.js";const p=["https://example.com/pukiwiki/?Your_Team/Your_Name*"];document.addEventListener("DOMContentLoaded",()=>{const o=document.getElementById("allowedUrls"),n=document.getElementById("shortcutApply"),d=document.getElementById("diffConfirmMode"),l=document.getElementById("markdownRoundtripCheck"),i=document.getElementById("saveBtn"),c=document.getElementById("status");chrome.storage.sync.get({allowedUrls:p,shortcutApply:!0,diffConfirmMode:"deletions_only",markdownRoundtripCheck:!0},e=>{o.value=e.allowedUrls.join(`
`),n.checked=e.shortcutApply,d.value=e.diffConfirmMode,l.checked=e.markdownRoundtripCheck});const s=()=>{const e=o.value.split(`
`).map(t=>t.trim()).filter(t=>t.length>0),r=e.filter(t=>!t.includes("*"));if(r.length>0){const t=r[0];if(!confirm(`URLの中にワイルドカード（*）が含まれていないものがあります。

例:
修正前: ${t}
修正後: ${t}*

特定の1ページのみで動作させたい場合を除き、配下の全ページで動作させるために末尾に * を付けることを強く推奨します。

このまま保存しますか？`))return}const m=n.checked,a=d.value,u=l.checked;chrome.storage.sync.set({allowedUrls:e,shortcutApply:m,diffConfirmMode:a,markdownRoundtripCheck:u},()=>{c.style.display="block",setTimeout(()=>{c.style.display="none"},2e3)})};i.addEventListener("click",s),document.addEventListener("keydown",e=>{(e.metaKey||e.ctrlKey)&&e.code==="Enter"&&(e.preventDefault(),s())})});
